

Start server by:   npm install && npm run start
