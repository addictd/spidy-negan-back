export const INCOMPLETE_ARGUMENTS = "INCOMPLETE_ARGUMENTS";
export const API_UNDER_CONSTRUCTION = "Ahoy! Api under construction.";

//CONSOLE MESSAGES
export const _ERR = msg => {
    console.log("[ERROR]: " + msg.toString());
    return "[ERROR]: " + msg.toString();
};