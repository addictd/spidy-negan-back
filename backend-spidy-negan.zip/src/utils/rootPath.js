import path from 'path';

const rootPath = path.join(__dirname , "../../");
export default rootPath;